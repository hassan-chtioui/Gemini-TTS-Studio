import { GoogleGenAI, Modality } from "@google/genai";
import { base64PcmToWavBlob } from "./audioUtils";
import { GeneratedAudio } from "../types";
import { VOICES } from "../constants";

// Initialize the client
const getClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateSpeech = async (
  text: string, 
  voiceId: string
): Promise<GeneratedAudio> => {
  const ai = getClient();
  
  // Find the real voice ID from our constants (maps aliases to actual Gemini voices)
  const voiceOption = VOICES.find(v => v.id === voiceId);
  const realVoiceName = voiceOption ? voiceOption.realVoiceId : voiceId;

  // Normalize text: Ensure it ends with punctuation to prevent rushing at the end
  let cleanText = text.trim();
  if (cleanText && !/[.!?]$/.test(cleanText)) {
    cleanText += ".";
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: cleanText }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: realVoiceName },
          },
        },
      },
    });

    const candidate = response.candidates?.[0];
    const base64Audio = candidate?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      throw new Error("No audio data received from Gemini.");
    }

    // Generate WAV for high-performance immediate playback
    const wavBlob = base64PcmToWavBlob(base64Audio, 24000);
    const wavUrl = URL.createObjectURL(wavBlob);

    // Return wavUrl for playback and raw data for lazy MP3 download
    return { wavUrl, base64Audio };

  } catch (error) {
    console.error("Gemini TTS Error:", error);
    throw error;
  }
};