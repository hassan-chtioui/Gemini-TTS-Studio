
declare var lamejs: any;

/**
 * Decodes a base64 string into a Uint8Array.
 */
export const decodeBase64 = (base64: string): Uint8Array => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

/**
 * Creates a standard WAV file header for the given PCM data.
 * Gemini TTS typically returns 24000Hz, 1 channel (Mono), 16-bit PCM.
 */
const createWavHeader = (dataLength: number, sampleRate: number): Uint8Array => {
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  
  const buffer = new ArrayBuffer(44);
  const view = new DataView(buffer);

  // RIFF identifier
  writeString(view, 0, 'RIFF');
  // file length
  view.setUint32(4, 36 + dataLength, true);
  // RIFF type
  writeString(view, 8, 'WAVE');
  // format chunk identifier
  writeString(view, 12, 'fmt ');
  // format chunk length
  view.setUint32(16, 16, true);
  // sample format (raw)
  view.setUint16(20, 1, true);
  // channel count
  view.setUint16(22, numChannels, true);
  // sample rate
  view.setUint32(24, sampleRate, true);
  // byte rate (sample rate * block align)
  view.setUint32(28, byteRate, true);
  // block align (channel count * bytes per sample)
  view.setUint16(32, blockAlign, true);
  // bits per sample
  view.setUint16(34, bitsPerSample, true);
  // data chunk identifier
  writeString(view, 36, 'data');
  // data chunk length
  view.setUint32(40, dataLength, true);

  return new Uint8Array(buffer);
};

const writeString = (view: DataView, offset: number, string: string) => {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
};

/**
 * Converts raw PCM base64 string from Gemini to a playable WAV Blob.
 */
export const base64PcmToWavBlob = (base64Pcm: string, sampleRate: number = 24000): Blob => {
  const pcmData = decodeBase64(base64Pcm);
  const header = createWavHeader(pcmData.length, sampleRate);
  
  // Combine header and data
  const wavBuffer = new Uint8Array(header.length + pcmData.length);
  wavBuffer.set(header);
  wavBuffer.set(pcmData, header.length);

  return new Blob([wavBuffer], { type: 'audio/wav' });
};

/**
 * Converts raw PCM base64 string from Gemini to an MP3 Blob using lamejs.
 */
export const base64PcmToMp3Blob = (base64Pcm: string, sampleRate: number = 24000): Blob => {
  if (typeof lamejs === 'undefined') {
    throw new Error('lamejs library not loaded. Please ensure internet connection.');
  }

  const pcmData = decodeBase64(base64Pcm);
  // Gemini returns 16-bit PCM. We need to create an Int16Array from the Uint8Array bytes.
  // Note: DataView or typed array constructor uses platform endianness. 
  // Gemini PCM is typically Little Endian, and browsers are typically Little Endian.
  const int16Data = new Int16Array(pcmData.buffer);

  const channels = 1;
  const kbps = 128;
  const mp3encoder = new lamejs.Mp3Encoder(channels, sampleRate, kbps);
  
  const mp3Data = [];
  
  // Encode the samples
  const mp3buf = mp3encoder.encodeBuffer(int16Data);
  if (mp3buf.length > 0) {
      mp3Data.push(mp3buf);
  }
  
  // Flush
  const endBuf = mp3encoder.flush();
  if (endBuf.length > 0) {
      mp3Data.push(endBuf);
  }

  return new Blob(mp3Data, { type: 'audio/mp3' });
};