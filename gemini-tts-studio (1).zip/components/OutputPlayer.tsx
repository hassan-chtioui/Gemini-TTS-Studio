import React, { useRef, useEffect, useState } from 'react';
import { GeneratedAudio } from '../types';
import { base64PcmToMp3Blob } from '../services/audioUtils';

interface OutputPlayerProps {
  audio: GeneratedAudio;
  targetDuration?: number; // Target duration in minutes
}

const OutputPlayer: React.FC<OutputPlayerProps> = ({ audio, targetDuration }) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  
  // nativeDuration is the length of the source file
  const [nativeDuration, setNativeDuration] = useState(0);
  
  // currentTime is the "virtual" time shown on the slider
  const [currentTime, setCurrentTime] = useState(0);
  
  // currentLoop tracks how many times we've looped (0-indexed)
  const [currentLoop, setCurrentLoop] = useState(0);
  
  const [playbackRate, setPlaybackRate] = useState(1.0);

  // Calculate the total "virtual" duration of the track
  const totalDuration = (targetDuration && targetDuration > 0) 
    ? targetDuration * 60 
    : nativeDuration;

  // Reset state when audio source changes
  useEffect(() => {
    setIsPlaying(false);
    setCurrentTime(0);
    setCurrentLoop(0);
    setPlaybackRate(1.0);
    if (audioRef.current) {
        audioRef.current.load();
        audioRef.current.playbackRate = 1.0;
    }
  }, [audio.wavUrl, targetDuration]);

  // Apply playback rate whenever it changes (Manual control only now)
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      // If we are at the end, restart
      if (currentTime >= totalDuration) {
          setCurrentTime(0);
          setCurrentLoop(0);
          audioRef.current.currentTime = 0;
      }
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current && nativeDuration > 0) {
      const nativeTime = audioRef.current.currentTime;
      
      // Calculate where we are in the "Virtual" timeline
      let virtualTime = (currentLoop * nativeDuration) + nativeTime;
      
      // Check for Trim case (if Native > Target)
      if (targetDuration && targetDuration > 0) {
          const targetSeconds = targetDuration * 60;
          if (virtualTime >= targetSeconds) {
              // Stop playing if we exceeded target
              audioRef.current.pause();
              setIsPlaying(false);
              virtualTime = targetSeconds;
          }
      }
      
      setCurrentTime(virtualTime);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const seekTime = parseFloat(e.target.value);
    setCurrentTime(seekTime);
    
    if (audioRef.current && nativeDuration > 0) {
        // Calculate which loop iteration this time belongs to
        const newLoop = Math.floor(seekTime / nativeDuration);
        
        // Calculate the time within that loop iteration
        // However, if we are in "Trim" mode (Target < Native), seekTime is just nativeTime
        // The modulo math handles both cases:
        // Case 1 (Loop): Seek 125s, Native 60s -> Loop 2, Native 5s.
        // Case 2 (Trim): Seek 125s, Native 600s -> Loop 0, Native 125s.
        
        // Special case: if targetDuration implies trimming, we assume loop 0 always if target < native
        // But the loop math works generally.
        
        const newNativeTime = seekTime % nativeDuration;
        
        setCurrentLoop(newLoop);
        audioRef.current.currentTime = newNativeTime;
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      const dur = audioRef.current.duration;
      if (isFinite(dur)) {
          setNativeDuration(dur);
      }
    }
  };

  const handleEnded = () => {
    if (targetDuration && targetDuration > 0 && nativeDuration > 0) {
        const targetSeconds = targetDuration * 60;
        
        // Calculate start time of next potential loop
        const nextLoopStartTime = (currentLoop + 1) * nativeDuration;
        
        // If the START of the next loop is within our target duration, we loop
        if (nextLoopStartTime < targetSeconds) {
            setCurrentLoop(prev => prev + 1);
            if (audioRef.current) {
                audioRef.current.currentTime = 0;
                audioRef.current.play();
            }
        } else {
            // Target reached or exceeded
            setIsPlaying(false);
            // We leave currentTime at the end
        }
    } else {
        // Normal behavior (no target duration)
        setIsPlaying(false);
        setCurrentTime(0);
        audioRef.current.currentTime = 0;
    }
  };

  const handleSpeedChange = () => {
    const speeds = [1.0, 1.25, 1.5, 0.75];
    const currentIndex = speeds.indexOf(playbackRate);
    const nextIndex = (currentIndex + 1) % speeds.length;
    
    if (currentIndex === -1) {
        setPlaybackRate(1.0);
    } else {
        setPlaybackRate(speeds[nextIndex]);
    }
  };

  const handleDownload = async () => {
    try {
        const mp3Blob = base64PcmToMp3Blob(audio.base64Audio, 24000);
        const mp3Url = URL.createObjectURL(mp3Blob);
        
        const link = document.createElement('a');
        link.href = mp3Url;
        link.download = `gemini-speech-${Date.now()}.mp3`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        setTimeout(() => URL.revokeObjectURL(mp3Url), 100);
    } catch (error) {
        console.error("MP3 conversion failed, falling back to WAV", error);
        alert("MP3 conversion failed. Downloading as WAV instead.");
        
        const link = document.createElement('a');
        link.href = audio.wavUrl;
        link.download = `gemini-speech-${Date.now()}.wav`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || !isFinite(seconds)) return "0:00";
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-6 backdrop-blur-sm animate-fade-in mt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-white flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
            </span>
            Generated Speech
        </h3>
        <div className="flex items-center gap-2">
            <button
                onClick={handleSpeedChange}
                className="px-3 py-1.5 text-xs font-medium border rounded-lg transition-colors bg-slate-700/50 hover:bg-slate-700 border-slate-600 text-slate-300"
                title="Change Playback Speed"
            >
                {playbackRate.toFixed(2)}x Speed
            </button>
            <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-200 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors group"
            >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 text-blue-400 group-hover:text-blue-300">
                <path fillRule="evenodd" d="M12 2.25a.75.75 0 0 1 .75.75v11.69l3.22-3.22a.75.75 0 1 1 1.06 1.06l-4.5 4.5a.75.75 0 0 1-1.06 0l-4.5-4.5a.75.75 0 1 1 1.06-1.06l3.22 3.22V3a.75.75 0 0 1 .75-.75Zm-9 13.5a.75.75 0 0 1 .75.75v2.25a1.5 1.5 0 0 0 1.5 1.5h13.5a1.5 1.5 0 0 0 1.5-1.5V16.5a.75.75 0 0 1 1.5 0v2.25a3 3 0 0 1-3 3H5.25a3 3 0 0 1-3-3V16.5a.75.75 0 0 1 .75-.75Z" clipRule="evenodd" />
            </svg>
            Download
            </button>
        </div>
      </div>

      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        src={audio.wavUrl}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleEnded}
        className="hidden"
      />

      <div className="flex items-center gap-4">
        {/* Play/Pause Button */}
        <button
          onClick={togglePlay}
          className="w-12 h-12 flex items-center justify-center rounded-full bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-lg shadow-blue-900/20 shrink-0"
        >
          {isPlaying ? (
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
              <path fillRule="evenodd" d="M6.75 5.25a.75.75 0 0 1 .75-.75H9a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H7.5a.75.75 0 0 1-.75-.75V5.25Zm7.5 0A.75.75 0 0 1 15 5.25h1.5a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H15a.75.75 0 0 1-.75-.75V5.25Z" clipRule="evenodd" />
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 ml-1">
              <path fillRule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" />
            </svg>
          )}
        </button>

        {/* Progress & Time */}
        <div className="flex-1 min-w-0">
            <div className="flex justify-between text-xs text-slate-400 mb-1 font-mono">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(totalDuration)}</span>
            </div>
            
            <div className="relative w-full h-4 flex items-center group">
                {/* Native Range Input for Seeking */}
                <input 
                    type="range"
                    min={0}
                    max={totalDuration || 100}
                    value={currentTime}
                    onChange={handleSeek}
                    className="
                      absolute w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer 
                      accent-blue-500 hover:accent-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50
                    "
                    style={{
                        backgroundSize: `${(currentTime / totalDuration) * 100}% 100%`,
                        backgroundImage: 'linear-gradient(#3b82f6, #3b82f6)'
                    }}
                />
                <style jsx>{`
                    input[type=range]::-webkit-slider-thumb {
                        -webkit-appearance: none;
                        height: 12px;
                        width: 12px;
                        border-radius: 50%;
                        background: #fff;
                        box-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
                        margin-top: -2px; /* Visual alignment */
                    }
                    input[type=range]::-webkit-slider-runnable-track {
                        -webkit-appearance: none;
                        box-shadow: none;
                        border: none;
                        background: transparent;
                    }
                `}</style>
            </div>
            
            {targetDuration && targetDuration > 0 && (
                <div className="text-[10px] text-blue-400 mt-1 text-right flex items-center justify-end gap-1">
                   {totalDuration > nativeDuration ? (
                       <>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
                          <path fillRule="evenodd" d="M4.755 10.059a7.5 7.5 0 0 1 12.548-3.364l1.903 1.903h-3.183a.75.75 0 1 0 0 1.5h4.992a.75.75 0 0 0 .75-.75V4.356a.75.75 0 0 0-1.5 0v3.18l-1.9-1.9A9 9 0 0 0 3.306 9.67a.75.75 0 1 0 1.45.388Zm15.408 3.352a.75.75 0 0 0-.919.53 7.5 7.5 0 0 1-12.548 3.364l-1.902-1.903h3.183a.75.75 0 0 0 0-1.5H2.984a.75.75 0 0 0-.75.75v4.992a.75.75 0 0 0 1.5 0v-3.18l1.9 1.9a9 9 0 0 0 15.059-4.035.75.75 0 0 0-.53-.918Z" clipRule="evenodd" />
                        </svg>
                        <span>Looping to fill {targetDuration} min</span>
                       </>
                   ) : (
                       <span>Playing first {targetDuration} min</span>
                   )}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default OutputPlayer;