import React, { useState, useRef, useEffect } from 'react';
import { VoiceOption } from '../types';
import { generateSpeech } from '../services/geminiService';

interface VoiceSelectorProps {
  selectedVoice: string;
  onSelect: (voiceId: string) => void;
  voices: VoiceOption[];
}

const VoiceSelector: React.FC<VoiceSelectorProps> = ({ selectedVoice, onSelect, voices }) => {
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);
  const [loadingVoice, setLoadingVoice] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  // Cache previews to avoid re-generating the same "Hello" message repeatedly
  // Key is now the voice.id (UI ID) to cache different named presets separately 
  // (though they might sound similar if mapped to same realVoiceId, the user expects them to be distinct entities)
  const previewCache = useRef<Map<string, string>>(new Map());

  useEffect(() => {
    return () => {
      // Cleanup audio on unmount
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const handlePlayPreview = async (e: React.MouseEvent, voice: VoiceOption) => {
    e.stopPropagation(); // Prevent selecting the voice when clicking play

    // If currently playing this voice, stop it
    if (playingVoice === voice.id) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      setPlayingVoice(null);
      return;
    }

    // Stop any other playing voice
    if (audioRef.current) {
      audioRef.current.pause();
      setPlayingVoice(null);
    }

    setLoadingVoice(voice.id);

    try {
      let audioUrl = previewCache.current.get(voice.id);

      if (!audioUrl) {
        // Generate preview if not in cache
        const result = await generateSpeech(
          `Hello! I am ${voice.name}.`,
          voice.id
        );
        // Use WAV URL for preview as it's faster to load/seek usually, though MP3 is fine too.
        audioUrl = result.wavUrl;
        previewCache.current.set(voice.id, audioUrl);
      }

      // Play audio
      const audio = new Audio(audioUrl);
      audioRef.current = audio;
      
      audio.onended = () => {
        setPlayingVoice(null);
      };
      
      await audio.play();
      setPlayingVoice(voice.id);

    } catch (error) {
      console.error("Failed to play preview", error);
    } finally {
      setLoadingVoice(null);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">
        Select Voice
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3 max-h-[600px] overflow-y-auto pr-2 scrollbar-thin">
        {voices.map((voice) => {
          const isSelected = selectedVoice === voice.id;
          const isPlaying = playingVoice === voice.id;
          const isLoading = loadingVoice === voice.id;

          return (
            <div
              key={voice.id}
              onClick={() => onSelect(voice.id)}
              className={`
                relative flex items-center p-3 rounded-xl border transition-all duration-200 cursor-pointer group
                ${
                  isSelected
                    ? 'bg-blue-600/10 border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.3)]'
                    : 'bg-slate-800/50 border-slate-700 hover:border-slate-500 hover:bg-slate-800'
                }
              `}
            >
              {/* Icon / Play Button Area */}
              <div 
                onClick={(e) => handlePlayPreview(e, voice)}
                className={`
                w-10 h-10 rounded-full flex items-center justify-center mr-3 text-base font-bold shrink-0 transition-all hover:scale-105 active:scale-95
                ${isSelected ? 'bg-blue-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}
              `}>
                {isLoading ? (
                   <svg className="animate-spin h-4 w-4 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                ) : isPlaying ? (
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                    <path fillRule="evenodd" d="M6.75 5.25a.75.75 0 0 1 .75-.75H9a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H7.5a.75.75 0 0 1-.75-.75V5.25Zm7.5 0A.75.75 0 0 1 15 5.25h1.5a.75.75 0 0 1 .75.75v13.5a.75.75 0 0 1-.75.75H15a.75.75 0 0 1-.75-.75V5.25Z" clipRule="evenodd" />
                  </svg>
                ) : (
                   <div className="relative w-full h-full flex items-center justify-center">
                      <span className="group-hover:hidden">{voice.name[0]}</span>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 hidden group-hover:block absolute">
                        <path fillRule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" />
                      </svg>
                   </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className={`font-medium truncate ${isSelected ? 'text-blue-400' : 'text-slate-200'}`}>
                    {voice.name}
                  </span>
                  <span className="text-[9px] px-1 py-px rounded border border-slate-700 bg-slate-800 text-slate-400 uppercase tracking-wide shrink-0">
                    {voice.gender}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 truncate">{voice.description}</p>
              </div>
              
              {isSelected && (
                <div className="absolute right-3 text-blue-500">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                    <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.36-1.814a.75.75 0 1 0-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 0 0-1.06 1.06l2.25 2.25a.75.75 0 0 0 1.14-.094l3.75-5.25Z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default VoiceSelector;